import json, os, re, time, uuid
from typing import Optional, Dict, Any, List, Tuple

import base64, hashlib, hmac, secrets, socket, subprocess

from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

import paramiko

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TAHA_DIR = "/opt/taha"
AUTH_PATH = os.path.join(TAHA_DIR, "auth.json")
SERVERS_PATH = os.path.join(TAHA_DIR, "servers.json")
TUNNELS_PATH = os.path.join(TAHA_DIR, "tunnels.json")
RESET_SCRIPT = "/etc/gost-reset.sh"
PANEL_SECRET_PATH = os.path.join(TAHA_DIR, "panel_secret.key")
if not os.path.exists(PANEL_SECRET_PATH):
    os.makedirs(TAHA_DIR, exist_ok=True)
    with open(PANEL_SECRET_PATH, "wb") as f:
        f.write(os.urandom(32))
with open(PANEL_SECRET_PATH, "rb") as f:
    SESSION_SECRET = f.read().hex()

app = FastAPI()
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    same_site="lax",
    https_only=False,
    max_age=60 * 60 * 24 * 7,
)
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
TAHA_VER = "20260217"
UPDATE_SH_URL = "https://raw.githubusercontent.com/Mdrzxsony/TaHa-Direct-Reverse-Tunnel-Runner/refs/heads/main/update.sh"
TAHA_RAW_URL = "https://raw.githubusercontent.com/Mdrzxsony/TaHa-Direct-Reverse-Tunnel-Runner/refs/heads/main/taha"
TAHA_SH_URL  = "https://raw.githubusercontent.com/Mdrzxsony/TaHa-Direct-Reverse-Tunnel-Runner/refs/heads/main/taha.sh"
GOST_VER = "3.2.7-nightly.20251122"

ALLOWED_PROTO1 = {
  "tcp","mtcp","udp","tls","mtls","ws","wss","mws","mwss","h2","h2c","grpc","pht",
  "quickcp","icmp","ohttp","otls","ftcp","http","http2","socks4","socks5","forward","relay"
}
ALLOWED_PROTO2 = {
  "tcp","mtcp","udp","tls","mtls","ws","wss","mws","mwss","h2","h2c","grpc","pht",
  "quickcp","icmp","ohttp","otls","ftcp","http","http2","socks4","socks5","relay","ssh","raw"
}

def is_allowed_proto1(p: str) -> bool:
    return (p or "").strip().lower() in ALLOWED_PROTO1

def is_allowed_proto2(p: str) -> bool:
    return (p or "").strip().lower() in ALLOWED_PROTO2

def parse_proto_pair_allowed(proto: str) -> Tuple[bool, str, str, str]:
    """
    Returns: (ok, normalized_full, p1, p2)
    """
    s = normalize_proto((proto or "").strip())
    parts = s.split("+")
    if len(parts) != 2:
        return False, s, "", ""
    p1, p2 = parts[0], parts[1]
    if not p1 or not p2:
        return False, s, "", ""
    if not re.match(r"^[a-z0-9_-]+$", p1) or not re.match(r"^[a-z0-9_-]+$", p2):
        return False, s, "", ""
    if not is_allowed_proto1(p1) or not is_allowed_proto2(p2):
        return False, s, p1, p2
    return True, s, p1, p2


FORWARD_SPEC_RE = re.compile(r"^(tcp|udp)=[0-9,\-]+$")

def valid_forward_spec(v: str) -> bool:
    v = (v or "").strip().lower()
    if not v:
        return False
    return bool(FORWARD_SPEC_RE.match(v))


PARAMS_RE = re.compile(r"^p=[A-Za-z0-9,._:/&;=\-]+$")

def normalize_params(p: str) -> str:
    return (p or "").strip()

def valid_params(p: str) -> bool:
    """
    Accept only:
      - empty string
      - or 'p=' followed by safe characters (no spaces, no quotes, no newlines)
    Also enforce length limit.
    """
    p = normalize_params(p)
    if not p:
        return True

    if not p.startswith("p="):
        return False

    if len(p) > 512:
        return False

    if re.search(r"[\s\r\n\t]", p):
        return False

    return bool(PARAMS_RE.match(p))


def _load_json(path: str, default):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return default

def _save_json_atomic(path: str, obj):
    tmp = path + ".tmp." + str(os.getpid())
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)

def _require_auth_file():
    if not os.path.exists(AUTH_PATH):
        salt = secrets.token_bytes(16)
        iters = 200_000
        dk = hashlib.pbkdf2_hmac("sha256", b"admin", salt, iters)
        _save_json_atomic(AUTH_PATH, {
            "username": "admin",
            "salt_b64": base64.b64encode(salt).decode(),
            "dk_b64": base64.b64encode(dk).decode(),
            "iters": iters
        })
        os.chmod(AUTH_PATH, 0o600)

def get_auth():
    _require_auth_file()
    return _load_json(AUTH_PATH, {})

def is_logged_in(req: Request) -> bool:
    return bool(req.session.get("logged_in") is True)

def require_login(req: Request):
    if not is_logged_in(req):
        raise HTTPException(status_code=401, detail="not logged in")

def login_required(req: Request):
    require_login(req)
    return True


def valid_ipv4(ip: str) -> bool:
    if not re.match(r"^(\d{1,3}\.){3}\d{1,3}$", ip): return False
    parts = ip.split(".")
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False

def valid_port(p: str) -> bool:
    if not re.match(r"^\d+$", p): return False
    n = int(p)
    return 1 <= n <= 65535

def valid_tid(tid: str) -> bool:
    if not re.match(r"^\d+$", tid): return False
    n = int(tid)
    return 1 <= n <= 99

def normalize_proto(p: str) -> str:
    p = (p or "").strip().replace(" ", "")
    p = p.lower()
    return p



def normalize_method(m: str) -> str:
    m = (m or "").strip().lower()
    if m in ("1","d","direct"): return "direct"
    if m in ("2","r","reverse"): return "reverse"
    return m

def proto_needs_ssh_id(proto: str) -> bool:
    return "ssh" in proto.split("+")

def need_forward_ports(method: str, side: str) -> bool:
    if method == "direct" and side == "iran": return True
    if method == "reverse" and side == "kharej": return True
    return False

def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if valid_ipv4(ip):
            return ip
    except Exception:
        pass
    try:
        ip = socket.gethostbyname(socket.gethostname())
        if valid_ipv4(ip):
            return ip
    except Exception:
        pass
    return "127.0.0.1"

def load_servers() -> List[Dict[str, Any]]:
    return _load_json(SERVERS_PATH, [])

def save_servers(servers):
    _save_json_atomic(SERVERS_PATH, servers)
    os.chmod(SERVERS_PATH, 0o600)

def load_tunnels() -> List[Dict[str, Any]]:
    return _load_json(TUNNELS_PATH, [])

def save_tunnels(tunnels):
    _save_json_atomic(TUNNELS_PATH, tunnels)
    os.chmod(TUNNELS_PATH, 0o600)

def find_server(sid: str) -> Optional[Dict[str, Any]]:
    for s in load_servers():
        if s.get("id") == sid:
            return s
    return None

def ssh_connect(host: str, port: int, username: str, password: str, timeout=10) -> paramiko.SSHClient:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(hostname=host, port=port, username=username, password=password, timeout=timeout, banner_timeout=timeout, auth_timeout=timeout)
    return c

def ssh_exec(c: paramiko.SSHClient, cmd: str, timeout=60) -> Tuple[int, str, str]:
    stdin, stdout, stderr = c.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode(errors="ignore")
    err = stderr.read().decode(errors="ignore")
    rc = stdout.channel.recv_exit_status()
    return rc, out, err

def ssh_exec_script(c: paramiko.SSHClient, script: str, timeout=240) -> Tuple[int, str, str]:
    """
    Run a multi-line bash script on remote via stdin (no quoting issues).
    """
    stdin, stdout, stderr = c.exec_command("bash -s", timeout=timeout)
    stdin.write(script)
    if not script.endswith("\n"):
        stdin.write("\n")
    stdin.channel.shutdown_write()
    out = stdout.read().decode(errors="ignore")
    err = stderr.read().decode(errors="ignore")
    rc = stdout.channel.recv_exit_status()
    return rc, out, err


def ssh_check_login(host, port, user, pwd) -> Tuple[bool, str]:
    try:
        c = ssh_connect_retry(host, int(port), user, pwd, timeout=8, retries=1)
        rc, out, err = ssh_exec(c, "echo OK", timeout=10)
        c.close()
        return (rc == 0 and "OK" in out), (err.strip() or out.strip() or "OK")
    except Exception as e:
        return False, str(e)

def _strip_ansi(s: str) -> str:
    return re.sub(r"\x1B\[[0-?]*[ -/]*[@-~]", "", s or "")

def _short_systemctl_status_text(full_text: str, unit: str) -> str:
    """
    Make Manage Tunnel status short:
      service name = ...
      Active: ...
      Loaded: ...
      status : start | stop
    """
    t = _strip_ansi(full_text or "")
    lines = [x.rstrip() for x in t.splitlines() if x.strip()]
    loaded = ""
    active = ""

    for ln in lines:
        s = ln.strip()
        if s.startswith("Loaded:"):
            loaded = s
        elif s.startswith("Active:"):
            active = s

    if not loaded:
        loaded = "Loaded: (unknown)"
    if not active:
        active = "Active: (unknown)"

    state = "stop"
    m = re.search(r"Active:\s+([a-zA-Z]+)", active)
    if m:
        state = "start" if m.group(1).lower() == "active" else "stop"

    return (
        f"service name = {unit}\n"
        f"{active}\n"
        f"{loaded}\n"
        f"status : {state}"
    )

def unit_is_active_local(unit: str) -> bool:
    p = subprocess.run(["bash", "-lc", f"systemctl is-active {unit}"], capture_output=True, text=True)
    return p.stdout.strip() == "active"

def unit_is_active_remote(c: paramiko.SSHClient, unit: str) -> bool:
    if not c:
        return False
    rc, out, err = ssh_exec(c, f"systemctl is-active {unit} 2>/dev/null || true", timeout=20)
    return (out.strip() == "active")

def unit_summary_local(unit: str) -> str:
    p = subprocess.run(["bash", "-lc", f"systemctl --no-pager --full status {unit}"], capture_output=True, text=True)
    txt = p.stdout or p.stderr or ""
    return _short_systemctl_status_text(txt, unit)

def unit_summary_remote(c: paramiko.SSHClient, unit: str) -> str:
    if not c:
        return _short_systemctl_status_text("", unit)
    rc, out, err = ssh_exec(c, f"systemctl --no-pager --full status {unit} 2>&1 || true", timeout=40)
    txt = out or err or ""
    return _short_systemctl_status_text(txt, unit)

def unit_logs_local(unit: str, lines: int = 200) -> str:
    lines = max(50, min(int(lines), 2000))
    p = subprocess.run(
        ["bash", "-lc", f"journalctl -u {unit} --no-pager -n {lines} --output=short-iso"],
        capture_output=True, text=True
    )
    return (p.stdout or p.stderr or "").strip() or "no logs"

def unit_logs_remote(c: paramiko.SSHClient, unit: str, lines: int = 200) -> str:
    lines = max(50, min(int(lines), 2000))
    if not c:
        return "no ssh"
    rc, out, err = ssh_exec(
        c, f"journalctl -u {unit} --no-pager -n {lines} --output=short-iso 2>&1 || true", timeout=60
    )
    return (out or err or "").strip() or "no logs"


REMOTE_BOOTSTRAP = r"""set -e
export TERM=xterm
export DEBIAN_FRONTEND=noninteractive
cd /root

LOCAL_VER="{TAHA_VER}"

get_ver() {{
  grep -Eo '^TAHA_VER="[^"]+"' "$1" 2>/dev/null | head -n1 | cut -d'"' -f2
}}

need_update=0

if [ ! -f ./taha ] || [ ! -s ./taha ]; then
  need_update=1
else
  v="$(get_ver ./taha)"
  [ -z "$v" ] && need_update=1
  [ "$v" != "$LOCAL_VER" ] && need_update=1
fi

if [ ! -f ./taha.sh ] || [ ! -s ./taha.sh ]; then
  need_update=1
else
  v="$(get_ver ./taha.sh)"
  [ -z "$v" ] && need_update=1
  [ "$v" != "$LOCAL_VER" ] && need_update=1
fi

if [ "$need_update" = "1" ]; then
  if [ ! -f ./update.sh ] || [ ! -s ./update.sh ]; then
    (command -v wget >/dev/null 2>&1 && wget -q -O update.sh "{UPDATE_SH_URL}?$(date +%s)") || \
    (command -v curl >/dev/null 2>&1 && curl -fsSL "{UPDATE_SH_URL}?$(date +%s)" -o update.sh)
    chmod +x update.sh || true
  fi
  bash ./update.sh
fi

if [ ! -f ./taha ] || [ ! -s ./taha ]; then
  (command -v wget >/dev/null 2>&1 && wget -q -O taha "{TAHA_URL}?$(date +%s)") || \
  (command -v curl >/dev/null 2>&1 && curl -fsSL "{TAHA_URL}?$(date +%s)" -o taha)
  chmod +x taha
fi
if [ ! -f ./taha.sh ] || [ ! -s ./taha.sh ]; then
  (command -v wget >/dev/null 2>&1 && wget -q -O taha.sh "{TAHA_SH_URL}?$(date +%s)") || \
  (command -v curl >/dev/null 2>&1 && curl -fsSL "{TAHA_SH_URL}?$(date +%s)" -o taha.sh)
  chmod +x taha.sh
fi

if [ ! -x /usr/local/bin/gost ]; then
  ARCH="$(uname -m || true)"
  case "$ARCH" in
    x86_64|amd64) A=amd64 ;;
    aarch64|arm64) A=arm64 ;;
    *) A=amd64 ;;
  esac
  TMP="/tmp/gost_{GOST_VER}_$A.$$"
  mkdir -p "$TMP"
  URL="https://github.com/go-gost/gost/releases/download/v{GOST_VER}/gost_{GOST_VER}_linux_$A.tar.gz"
  (command -v wget >/dev/null 2>&1 && wget -q -O "$TMP/g.tgz" "$URL") || \
  (command -v curl >/dev/null 2>&1 && curl -fsSL "$URL" -o "$TMP/g.tgz")
  tar -xzf "$TMP/g.tgz" -C "$TMP"
  chmod +x "$TMP/gost"
  cp -f "$TMP/gost" /usr/local/bin/gost
  rm -rf "$TMP"
fi
"""

def remote_ensure(c: paramiko.SSHClient) -> None:
    script = REMOTE_BOOTSTRAP.format(
        TAHA_URL=TAHA_RAW_URL,
        TAHA_SH_URL=TAHA_SH_URL,
        UPDATE_SH_URL=UPDATE_SH_URL,
        TAHA_VER=TAHA_VER,
        GOST_VER=GOST_VER,
    )
    rc, out, err = ssh_exec_script(c, script, timeout=240)
    if rc != 0:
        raise RuntimeError(err.strip() or out.strip() or f"bootstrap failed rc={rc}")

def remote_run_cli(c: paramiko.SSHClient, cli: str) -> None:
    script = f"""set -e
export TERM=xterm
export DEBIAN_FRONTEND=noninteractive
cd /root
timeout 180s bash -lc 'printf "\\n" | {cli} >/dev/null 2>&1'
"""
    rc, out, err = ssh_exec_script(c, script, timeout=240)
    if rc != 0:
        raise RuntimeError(err.strip() or out.strip() or f"cli failed rc={rc}")


def remote_unit_name(side: str, tid: str) -> str:
    return f"gost-{side}-{tid}.service"


def remote_service_action(c: paramiko.SSHClient, unit: str, action: str) -> str:
    action = action.strip().lower()
    if action not in ("start","stop","restart","enable","disable"):
        raise RuntimeError("bad action")
    rc, out, err = ssh_exec(c, f"systemctl {action} {unit} >/dev/null 2>&1 || true; systemctl --no-pager --full status {unit} | sed -n '1,10p'", timeout=80)
    return (out.strip() or err.strip() or "OK")

def remote_uninstall_unit(c: paramiko.SSHClient, unit: str) -> str:
    script = f"""set +e
systemctl stop {unit} >/dev/null 2>&1 || true
systemctl kill -s SIGKILL {unit} >/dev/null 2>&1 || true
systemctl disable {unit} >/dev/null 2>&1 || true
rm -f /etc/systemd/system/{unit} >/dev/null 2>&1 || true
rm -rf /etc/systemd/system/{unit}.d >/dev/null 2>&1 || true
for d in /etc/systemd/system/*.wants /etc/systemd/system/*/*.wants; do rm -f "$d/{unit}" >/dev/null 2>&1 || true; done
systemctl daemon-reload >/dev/null 2>&1 || true
systemctl reset-failed {unit} >/dev/null 2>&1 || true
echo OK
"""
    rc, out, err = ssh_exec_script(c, script, timeout=90)
    if rc != 0:
        return err.strip() or out.strip() or "ERR"
    return out.strip()


LOCAL_BOOTSTRAP = r"""set -e
export TERM=xterm
export DEBIAN_FRONTEND=noninteractive
cd /root

LOCAL_VER="{TAHA_VER}"

get_ver() {{
  grep -Eo '^TAHA_VER="[^"]+"' "$1" 2>/dev/null | head -n1 | cut -d'"' -f2
}}

need_update=0

if [ ! -f ./taha ] || [ ! -s ./taha ]; then
  need_update=1
else
  v="$(get_ver ./taha)"
  [ -z "$v" ] && need_update=1
  [ "$v" != "$LOCAL_VER" ] && need_update=1
fi

if [ ! -f ./taha.sh ] || [ ! -s ./taha.sh ]; then
  need_update=1
else
  v="$(get_ver ./taha.sh)"
  [ -z "$v" ] && need_update=1
  [ "$v" != "$LOCAL_VER" ] && need_update=1
fi

if [ "$need_update" = "1" ]; then
  if [ ! -f ./update.sh ] || [ ! -s ./update.sh ]; then
    (command -v wget >/dev/null 2>&1 && wget -q -O update.sh "{UPDATE_SH_URL}?$(date +%s)") || \
    (command -v curl >/dev/null 2>&1 && curl -fsSL "{UPDATE_SH_URL}?$(date +%s)" -o update.sh)
    chmod +x update.sh || true
  fi
  bash ./update.sh
fi

if [ ! -f ./taha ] || [ ! -s ./taha ]; then
  (command -v wget >/dev/null 2>&1 && wget -q -O taha "{TAHA_URL}?$(date +%s)") || \
  (command -v curl >/dev/null 2>&1 && curl -fsSL "{TAHA_URL}?$(date +%s)" -o taha)
  chmod +x taha
fi
if [ ! -f ./taha.sh ] || [ ! -s ./taha.sh ]; then
  (command -v wget >/dev/null 2>&1 && wget -q -O taha.sh "{TAHA_SH_URL}?$(date +%s)") || \
  (command -v curl >/dev/null 2>&1 && curl -fsSL "{TAHA_SH_URL}?$(date +%s)" -o taha.sh)
  chmod +x taha.sh
fi

if [ ! -x /usr/local/bin/gost ]; then
  ARCH="$(uname -m || true)"
  case "$ARCH" in
    x86_64|amd64) A=amd64 ;;
    aarch64|arm64) A=arm64 ;;
    *) A=amd64 ;;
  esac
  TMP="/tmp/gost_{GOST_VER}_$A.$$"
  mkdir -p "$TMP"
  URL="https://github.com/go-gost/gost/releases/download/v{GOST_VER}/gost_{GOST_VER}_linux_$A.tar.gz"
  (command -v wget >/dev/null 2>&1 && wget -q -O "$TMP/g.tgz" "$URL") || \
  (command -v curl >/dev/null 2>&1 && curl -fsSL "$URL" -o "$TMP/g.tgz")
  tar -xzf "$TMP/g.tgz" -C "$TMP"
  chmod +x "$TMP/gost"
  cp -f "$TMP/gost" /usr/local/bin/gost
  rm -rf "$TMP"
fi
"""

def local_ensure() -> None:
    cmd = LOCAL_BOOTSTRAP.format(
        TAHA_URL=TAHA_RAW_URL,
        TAHA_SH_URL=TAHA_SH_URL,
        UPDATE_SH_URL=UPDATE_SH_URL,
        TAHA_VER=TAHA_VER,
        GOST_VER=GOST_VER,
    )
    p = subprocess.run(["bash","-lc",cmd], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip() or f"local bootstrap failed rc={p.returncode}")


def local_run_cli(cli: str) -> None:
    cmd = f"""
set -e
export TERM=xterm
export DEBIAN_FRONTEND=noninteractive
cd /root
timeout 180s bash -lc 'printf "\\n" | {cli} >/dev/null 2>&1'
"""
    p = subprocess.run(["bash","-lc", cmd], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip() or f"local cli failed rc={p.returncode}")



def local_service_action(unit: str, action: str) -> str:
    action = action.strip().lower()
    if action not in ("start","stop","restart","enable","disable"):
        raise RuntimeError("bad action")
    p = subprocess.run(["bash","-lc",f"systemctl {action} {unit} >/dev/null 2>&1 || true; systemctl --no-pager --full status {unit} | sed -n '1,10p'"], capture_output=True, text=True)
    return (p.stdout.strip() or p.stderr.strip() or "OK")

def local_uninstall_unit(unit: str) -> str:
    script = f"""
set +e
systemctl stop {unit} >/dev/null 2>&1 || true
systemctl kill -s SIGKILL {unit} >/dev/null 2>&1 || true
systemctl disable {unit} >/dev/null 2>&1 || true
rm -f /etc/systemd/system/{unit} >/dev/null 2>&1 || true
rm -rf /etc/systemd/system/{unit}.d >/dev/null 2>&1 || true
for d in /etc/systemd/system/*.wants /etc/systemd/system/*/*.wants; do rm -f "$d/{unit}" >/dev/null 2>&1 || true; done
systemctl daemon-reload >/dev/null 2>&1 || true
systemctl reset-failed {unit} >/dev/null 2>&1 || true
echo OK
"""
    p = subprocess.run(["bash","-lc",script], capture_output=True, text=True)
    if p.returncode != 0:
        return p.stderr.strip() or p.stdout.strip() or "ERR"
    return p.stdout.strip()

def build_cli(
    side: str,
    method: str,
    proto: str,
    tid: str,
    peer_ip: str,
    tun_port: str,
    fwd_ports: str = "",
    ssh_id: str = "",
    params: str = ""
) -> str:
    base = f"./taha {side} {method} {proto} {tid} {peer_ip} {tun_port}"
    if fwd_ports:
        base += f" {fwd_ports}"
    if ssh_id:
        base += f" {ssh_id}"
    if params:
        base += f" {params}"
    return base


@app.get("/", response_class=HTMLResponse)
def home(req: Request):
    if not is_logged_in(req):
        return RedirectResponse("/login", status_code=302)
    tunnels = load_tunnels()
    return templates.TemplateResponse("home.html", {"request": req, "tunnels": tunnels})

@app.get("/login", response_class=HTMLResponse)
def login_get(req: Request):
    return templates.TemplateResponse("login.html", {"request": req, "err": ""})

@app.post("/login", response_class=HTMLResponse)
def login_post(req: Request, username: str = Form(...), password: str = Form(...)):
    auth = get_auth()
    if username != auth.get("username"):
        return templates.TemplateResponse("login.html", {"request": req, "err": "Invalid credentials"})
    try:
        salt = base64.b64decode(auth["salt_b64"])
        dk_stored = base64.b64decode(auth["dk_b64"])
        iters = int(auth.get("iters", 200_000))
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iters)
        if hmac.compare_digest(dk, dk_stored):
            req.session["logged_in"] = True
            return RedirectResponse("/", status_code=302)
    except Exception:
        pass
    return templates.TemplateResponse("login.html", {"request": req, "err": "Invalid credentials"})

@app.get("/logout")
def logout(req: Request):
    req.session.clear()
    return RedirectResponse("/login", status_code=302)

@app.get("/servers/add", response_class=HTMLResponse)
def servers_add_get(req: Request, ok: str = "", err: str = "", _: bool = Depends(login_required)):
    return templates.TemplateResponse("servers_add.html", {"request": req, "ok": ok, "err": err})

@app.post("/servers/add", response_class=HTMLResponse)
def servers_add_post(
    req: Request,
    side: str = Form(...),
    host: str = Form(...),
    ssh_port: str = Form(...),
    ssh_user: str = Form(...),
    ssh_pass: str = Form(...),
    _: bool = Depends(login_required)
):
    side = side.strip().lower()
    host = host.strip()
    ssh_user = ssh_user.strip()

    if side not in ("iran","kharej"):
        return templates.TemplateResponse("servers_add.html", {"request": req, "ok":"", "err":"bad side"})
    if not valid_ipv4(host):
        return templates.TemplateResponse("servers_add.html", {"request": req, "ok":"", "err":"invalid ipv4"})
    if not valid_port(ssh_port):
        return templates.TemplateResponse("servers_add.html", {"request": req, "ok":"", "err":"invalid ssh port"})

    ok, msg = ssh_check_login(host, int(ssh_port), ssh_user, ssh_pass)
    if not ok:
        return templates.TemplateResponse("servers_add.html", {"request": req, "ok":"", "err":f"ssh check failed: {msg}"})

    servers = load_servers()
    sid = uuid.uuid4().hex[:10]
    servers.append({"id": sid, "side": side, "host": host, "ssh_port": int(ssh_port), "ssh_user": ssh_user, "ssh_pass": ssh_pass})
    save_servers(servers)
    return RedirectResponse("/servers/list?ok=Server+added", status_code=302)

@app.get("/servers/list", response_class=HTMLResponse)
def servers_list(req: Request, ok: str = "", err: str = "", _: bool = Depends(login_required)):
    servers = load_servers()
    return templates.TemplateResponse("servers_list.html", {"request": req, "servers": servers, "ok": ok, "err": err})

@app.get("/servers/edit/{sid}", response_class=HTMLResponse)
def servers_edit_get(req: Request, sid: str, ok: str = "", err: str = "", _: bool = Depends(login_required)):
    s = find_server(sid)
    if not s:
        return RedirectResponse("/servers/list?err=Not+found", status_code=302)
    s2 = dict(s)
    s2["ssh_pass"] = ""
    return templates.TemplateResponse("servers_edit.html", {"request": req, "s": s2, "ok": ok, "err": err})

@app.post("/servers/edit/{sid}", response_class=HTMLResponse)
def servers_edit_post(
    req: Request,
    sid: str,
    side: str = Form(...),
    host: str = Form(...),
    ssh_port: str = Form(...),
    ssh_user: str = Form(...),
    ssh_pass: str = Form(""),
    _: bool = Depends(login_required)
):
    servers = load_servers()
    idx = next((i for i,x in enumerate(servers) if x.get("id")==sid), -1)
    if idx < 0:
        return RedirectResponse("/servers/list?err=Not+found", status_code=302)

    side = side.strip().lower()
    host = host.strip()
    ssh_user = ssh_user.strip()

    if side not in ("iran","kharej"):
        return RedirectResponse(f"/servers/edit/{sid}?err=bad+side", status_code=302)
    if not valid_ipv4(host):
        return RedirectResponse(f"/servers/edit/{sid}?err=invalid+ipv4", status_code=302)
    if not valid_port(ssh_port):
        return RedirectResponse(f"/servers/edit/{sid}?err=invalid+ssh+port", status_code=302)

    if ssh_pass.strip() == "":
        ssh_pass = servers[idx].get("ssh_pass","")

    ok, msg = ssh_check_login(host, int(ssh_port), ssh_user, ssh_pass)
    if not ok:
        return RedirectResponse(f"/servers/edit/{sid}?err=ssh+check+failed:+{msg}".replace(" ", "+"), status_code=302)

    servers[idx].update({"side": side, "host": host, "ssh_port": int(ssh_port), "ssh_user": ssh_user, "ssh_pass": ssh_pass})
    save_servers(servers)
    return RedirectResponse("/servers/list?ok=Saved", status_code=302)

@app.post("/servers/test/{sid}")
def servers_test(req: Request, sid: str, _: bool = Depends(login_required)):
    s = find_server(sid)
    if not s:
        return JSONResponse({"ok": False, "msg": "not found"})
    try:
        c, s2 = ssh_connect_server_retry(sid, timeout=8, retries=1)
        rc, out, err = ssh_exec(c, "echo OK", timeout=10)
        c.close()
        ok = (rc == 0 and "OK" in out)
        msg = (err.strip() or out.strip() or "OK")
        return JSONResponse({"ok": ok, "msg": msg})
    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)})

@app.get("/tunnels/create", response_class=HTMLResponse)
def create_step1(req: Request, _: bool = Depends(login_required)):
    req.session["wizard"] = {}
    return templates.TemplateResponse("create_step1.html", {"request": req})

@app.post("/tunnels/create/step1", response_class=HTMLResponse)
def create_step1_post(req: Request, mode: str = Form(...), _: bool = Depends(login_required)):
    mode = mode.strip().lower()
    if mode not in ("im_iran","im_kharej","im_outside"):
        return RedirectResponse("/tunnels/create", status_code=302)
    req.session["wizard"] = {"mode": mode}
    return RedirectResponse("/tunnels/create/step2", status_code=302)

@app.get("/tunnels/create/step2", response_class=HTMLResponse)
def create_step2(req: Request, err: str = "", _: bool = Depends(login_required)):
    w = req.session.get("wizard") or {}
    mode = (w.get("mode") or "").strip()

    if mode not in ("im_iran", "im_kharej", "im_outside"):
        return RedirectResponse("/tunnels/create?err=session_expired", status_code=302)

    servers = load_servers()
    iran_list = [s for s in servers if s.get("side") == "iran"]
    kh_list = [s for s in servers if s.get("side") == "kharej"]
    return templates.TemplateResponse("create_step2.html", {
        "request": req,
        "mode": mode,
        "iran_list": iran_list,
        "kh_list": kh_list,
        "err": err
    })


@app.post("/tunnels/create/step2", response_class=HTMLResponse)
def create_step2_post(
    req: Request,
    mode: str = Form(...),

    iran_pick: str = Form(""),
    kh_pick: str = Form(""),

    new_iran_ip: str = Form(""),
    new_iran_port: str = Form(""),
    new_iran_user: str = Form(""),
    new_iran_pass: str = Form(""),

    new_kh_ip: str = Form(""),
    new_kh_port: str = Form(""),
    new_kh_user: str = Form(""),
    new_kh_pass: str = Form(""),

    _: bool = Depends(login_required)
):
    mode = mode.strip().lower()
    servers = load_servers()

    def add_server(side, ip, port, user, pw) -> Tuple[Optional[str], str]:
        ip = ip.strip(); user=user.strip()
        if not valid_ipv4(ip): return None, "invalid ip"
        if not valid_port(port): return None, "invalid ssh port"
        ok, msg = ssh_check_login(ip, int(port), user, pw)
        if not ok: return None, f"ssh failed: {msg}"
        sid = uuid.uuid4().hex[:10]
        servers.append({"id":sid,"side":side,"host":ip,"ssh_port":int(port),"ssh_user":user,"ssh_pass":pw})
        save_servers(servers)
        return sid, "ok"

    def check_pick(sid: str) -> Tuple[Optional[str], str]:
        sid = sid.strip()
        if not sid: return None, "no server selected"
        s = next((x for x in servers if x.get("id")==sid), None)
        if not s: return None, "server not found"
        ok, msg = ssh_check_login(s["host"], int(s["ssh_port"]), s["ssh_user"], s["ssh_pass"])
        if not ok: return None, f"ssh failed: {msg}"
        return sid, "ok"

    w = req.session.get("wizard") or {}
    w["mode"] = mode

    if mode == "im_iran":
        if kh_pick:
            sid, msg = check_pick(kh_pick)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["kharej_sid"]=sid
        else:
            sid, msg = add_server("kharej", new_kh_ip, new_kh_port, new_kh_user, new_kh_pass)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["kharej_sid"]=sid

    elif mode == "im_kharej":
        if iran_pick:
            sid, msg = check_pick(iran_pick)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["iran_sid"]=sid
        else:
            sid, msg = add_server("iran", new_iran_ip, new_iran_port, new_iran_user, new_iran_pass)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["iran_sid"]=sid

    else:
        if iran_pick:
            sid, msg = check_pick(iran_pick)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["iran_sid"]=sid
        else:
            sid, msg = add_server("iran", new_iran_ip, new_iran_port, new_iran_user, new_iran_pass)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["iran_sid"]=sid

        if kh_pick:
            sid, msg = check_pick(kh_pick)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["kharej_sid"]=sid
        else:
            sid, msg = add_server("kharej", new_kh_ip, new_kh_port, new_kh_user, new_kh_pass)
            if not sid: return RedirectResponse("/tunnels/create/step2?err="+msg.replace(" ","+"), status_code=302)
            w["kharej_sid"]=sid

    req.session["wizard"]=w
    return RedirectResponse("/tunnels/create/step3", status_code=302)

@app.get("/tunnels/create/step3", response_class=HTMLResponse)
def create_step3(req: Request, err: str = "", _: bool = Depends(login_required)):
    w = req.session.get("wizard") or {}
    mode = (w.get("mode") or "").strip()

    if mode not in ("im_iran", "im_kharej", "im_outside"):
        return RedirectResponse("/tunnels/create?err=session_expired", status_code=302)

    servers = load_servers()
    iran = next((s for s in servers if s.get("id") == w.get("iran_sid")), None)
    kh = next((s for s in servers if s.get("id") == w.get("kharej_sid")), None)

    local_ip = get_local_ip()
    return templates.TemplateResponse("create_step3.html", {
        "request": req,
        "mode": mode,
        "local_ip": local_ip,
        "iran": iran,
        "kharej": kh,
        "err": err,
    })

@app.post("/tunnels/create/run", response_class=HTMLResponse)
def create_run(
    req: Request,
    method: str = Form(...),
    proto: str = Form(...),
    tid: str = Form(...),
    tun_port: str = Form(...),

    forward_ports: str = Form(""),
    ssh_id: str = Form(""),
    params: str = Form(""),

    _: bool = Depends(login_required)
):
    w = req.session.get("wizard") or {}
    mode = (w.get("mode") or "").strip()
    if mode not in ("im_iran", "im_kharej", "im_outside"):
        return RedirectResponse("/tunnels/create?err=session_expired", status_code=302)

    method = normalize_method(method)
    tid = (tid or "").strip()
    tun_port = (tun_port or "").strip()
    forward_ports = (forward_ports or "").strip()
    ssh_id = (ssh_id or "").strip()
    params = normalize_params(params)

    if method not in ("direct", "reverse"):
        return RedirectResponse("/tunnels/create/step3?err=bad+method", status_code=302)

    ok_pair, proto_norm, p1, p2 = parse_proto_pair_allowed(proto)
    if not ok_pair:
        return RedirectResponse("/tunnels/create/step3?err=bad+proto", status_code=302)
    proto = proto_norm

    if not valid_tid(tid):
        return RedirectResponse("/tunnels/create/step3?err=bad+tid", status_code=302)
    if not valid_port(tun_port):
        return RedirectResponse("/tunnels/create/step3?err=bad+tun+port", status_code=302)

    if proto_needs_ssh_id(proto) and not valid_tid(ssh_id):
        return RedirectResponse("/tunnels/create/step3?err=SSH_ID+required", status_code=302)

    if not valid_params(params):
        return RedirectResponse("/tunnels/create/step3?err=bad+params", status_code=302)

    servers = load_servers()
    iran = next((s for s in servers if s.get("id") == w.get("iran_sid")), None)
    kh = next((s for s in servers if s.get("id") == w.get("kharej_sid")), None)

    local_ip = get_local_ip()

    if mode == "im_iran":
        if not kh:
            return RedirectResponse("/tunnels/create/step3?err=kharej+missing", status_code=302)
        iran_ip = local_ip
        kh_ip = kh["host"]
        local_side = "iran"

    elif mode == "im_kharej":
        if not iran:
            return RedirectResponse("/tunnels/create/step3?err=iran+missing", status_code=302)
        kh_ip = local_ip
        iran_ip = iran["host"]
        local_side = "kharej"

    else:
        if not iran or not kh:
            return RedirectResponse("/tunnels/create/step3?err=need+both+servers", status_code=302)
        iran_ip = iran["host"]
        kh_ip = kh["host"]
        local_side = ""

    forwarder_side = "iran" if method == "direct" else "kharej"
    if need_forward_ports(method, forwarder_side):
        if not forward_ports:
            return RedirectResponse("/tunnels/create/step3?err=FORWARD_PORTS+required", status_code=302)
        if not valid_forward_spec(forward_ports):
            return RedirectResponse("/tunnels/create/step3?err=bad+FORWARD_PORTS", status_code=302)

    c_iran = None
    c_kh = None

    iran_sid = w.get("iran_sid") or ""
    kh_sid = w.get("kharej_sid") or ""

    try:
        if local_side in ("iran", "kharej"):
            local_ensure()

        if mode == "im_iran":
            c_kh, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
            remote_ensure(c_kh)

        elif mode == "im_kharej":
            c_iran, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
            remote_ensure(c_iran)

        else:
            c_iran, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
            c_kh, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
            remote_ensure(c_iran)
            remote_ensure(c_kh)

        sshid_arg = ssh_id if proto_needs_ssh_id(proto) else ""

        cli_kh_direct = build_cli("kharej", "direct", proto, tid, iran_ip, tun_port, params=params)

        cli_ir_direct = build_cli(
            "iran", "direct", proto, tid, kh_ip, tun_port,
            forward_ports if need_forward_ports("direct", "iran") else "",
            sshid_arg if need_forward_ports("direct", "iran") else "",
            params=params
        )

        cli_ir_reverse = build_cli("iran", "reverse", proto, tid, kh_ip, tun_port, params=params)

        cli_kh_reverse = build_cli(
            "kharej", "reverse", proto, tid, iran_ip, tun_port,
            forward_ports if need_forward_ports("reverse", "kharej") else "",
            sshid_arg if need_forward_ports("reverse", "kharej") else "",
            params=params
        )

        u_ir = remote_unit_name("iran", tid)
        u_kh = remote_unit_name("kharej", tid)

        def _uninstall_side(side: str):
            unit = remote_unit_name(side, tid)
            if side == local_side:
                local_uninstall_unit(unit)
                return
            if side == "iran":
                if c_iran:
                    remote_uninstall_unit(c_iran, unit)
                return
            if side == "kharej":
                if c_kh:
                    remote_uninstall_unit(c_kh, unit)
                return

        def _is_active(side: str) -> bool:
            unit = remote_unit_name(side, tid)
            if side == local_side:
                return unit_is_active_local(unit)
            if side == "iran":
                return unit_is_active_remote(c_iran, unit) if c_iran else False
            if side == "kharej":
                return unit_is_active_remote(c_kh, unit) if c_kh else False
            return False

        def _run_on_side(side: str, cli: str):
            if side == local_side:
                local_run_cli(cli)
                return
            if side == "iran":
                if not c_iran:
                    raise RuntimeError("iran ssh not connected")
                remote_run_cli(c_iran, cli)
                return
            if side == "kharej":
                if not c_kh:
                    raise RuntimeError("kharej ssh not connected")
                remote_run_cli(c_kh, cli)
                return
            raise RuntimeError("bad side")

        if method == "direct":
            first_side, first_cli = "kharej", cli_kh_direct
            second_side, second_cli = "iran", cli_ir_direct
        else:
            first_side, first_cli = "iran", cli_ir_reverse
            second_side, second_cli = "kharej", cli_kh_reverse

        try:
            _run_on_side(first_side, first_cli)

            _run_on_side(second_side, second_cli)

        except Exception as e_run:
            try:
                _uninstall_side(first_side)
            except Exception:
                pass
            try:
                _uninstall_side(second_side)
            except Exception:
                pass
            raise RuntimeError(str(e_run))
            
        if local_side == "iran":
            st_ir = "iran side : done | " + unit_summary_local(u_ir)
        else:
            st_ir = "iran side : done | " + (unit_summary_remote(c_iran, u_ir) if c_iran else "iran side : error (no ssh)")

        if local_side == "kharej":
            st_kh = "Kharej Side  : done | " + unit_summary_local(u_kh)
        else:
            st_kh = "Kharej Side  : done | " + (unit_summary_remote(c_kh, u_kh) if c_kh else "Kharej Side  : error (no ssh)")

        try:
            if c_iran: c_iran.close()
        except Exception:
            pass
        try:
            if c_kh: c_kh.close()
        except Exception:
            pass

        tunnels = load_tunnels()

        iran_sid_key = (iran["id"] if iran else "LOCAL_IRAN") if mode != "im_iran" else "LOCAL_IRAN"
        kh_sid_key = (kh["id"] if kh else "LOCAL_KHAREJ") if mode != "im_kharej" else "LOCAL_KHAREJ"

        key = f"{iran_sid_key}::{kh_sid_key}::{tid}"
        entry = {
            "key": key,
            "mode": mode,
            "iran_server_id": iran["id"] if iran else "",
            "kharej_server_id": kh["id"] if kh else "",
            "iran_ip": iran_ip,
            "kharej_ip": kh_ip,
            "method": method,
            "proto": proto,
            "tid": tid,
            "tun_port": tun_port,
            "forward_ports": forward_ports,
            "ssh_id": ssh_id,
            "params": params,
            "created_at": int(time.time())
        }

        existing = next((t for t in tunnels if t.get("key") == key), None)
        if existing:
            tunnels = [entry if t.get("key") == key else t for t in tunnels]
        else:
            tunnels.append(entry)
        save_tunnels(tunnels)

        req.session["wizard"] = {}
        return templates.TemplateResponse("create_done.html", {"request": req, "ir_status": st_ir, "kh_status": st_kh})

    except Exception as e:
        try:
            if c_iran: c_iran.close()
        except Exception:
            pass
        try:
            if c_kh: c_kh.close()
        except Exception:
            pass
        return RedirectResponse("/tunnels/create/step3?err=" + str(e).replace(" ", "+"), status_code=302)

@app.get("/tunnels", response_class=HTMLResponse)
def tunnels_list(req: Request, ok: str = "", err: str = "", _: bool = Depends(login_required)):
    tunnels = load_tunnels()
    return templates.TemplateResponse("tunnels_list.html", {"request": req, "tunnels": tunnels, "ok": ok, "err": err})

def resolve_tunnel_servers(t: Dict[str,Any]):
    mode = t.get("mode","im_outside")
    local_side = "iran" if mode=="im_iran" else ("kharej" if mode=="im_kharej" else "")
    iran = find_server(t.get("iran_server_id","")) if t.get("iran_server_id") else None
    kh = find_server(t.get("kharej_server_id","")) if t.get("kharej_server_id") else None
    return mode, local_side, iran, kh

@app.get("/tunnels/manage/{tkey}", response_class=HTMLResponse)
def tunnels_manage(
    req: Request,
    tkey: str,
    err: str = "",
    ok: str = "",
    _: bool = Depends(login_required)
):
    tunnels = load_tunnels()
    t = next((x for x in tunnels if x.get("key") == tkey), None)
    if not t:
        return RedirectResponse("/tunnels", status_code=302)

    if "params" not in t:
        t["params"] = ""
    if "ssh_id" not in t:
        t["ssh_id"] = ""
    if "forward_ports" not in t:
        t["forward_ports"] = ""
    if "proto" not in t:
        t["proto"] = ""
    if "tun_port" not in t:
        t["tun_port"] = ""
    if "method" not in t:
        t["method"] = "direct"

    try:
        t["params"] = normalize_params(t.get("params", ""))
    except Exception:
        t["params"] = (t.get("params") or "").strip()

    ctx = {
        "request": req,
        "t": t,
        "err": err,
        "ok": ok,
    }
    return templates.TemplateResponse("tunnel_manage.html", ctx)
    
@app.get("/api/tunnels/status/{tkey}")
def tunnels_status(req: Request, tkey: str, _: bool = Depends(login_required)):
    t = next((x for x in load_tunnels() if x.get("key") == tkey), None)
    if not t:
        return JSONResponse({"ok": False, "msg": "not found"})

    mode, local_side, iran, kh = resolve_tunnel_servers(t)
    tid = t["tid"]
    u_ir = remote_unit_name("iran", tid)
    u_kh = remote_unit_name("kharej", tid)

    iran_ok, kh_ok = True, True
    ir_txt, kh_txt = "", ""

    try:
        if local_side == "iran":
            ir_txt = unit_summary_local(u_ir)
        else:
            iran_sid = t.get("iran_server_id") or ""
            if not iran_sid:
                iran_ok = False
                ir_txt = f"service name = {u_ir}\niran server missing"
            else:
                c, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
                ir_txt = unit_summary_remote(c, u_ir)
                c.close()
    except Exception as e:
        iran_ok = False
        ir_txt = f"service name = {u_ir}\nERROR: {str(e)}"

    try:
        if local_side == "kharej":
            kh_txt = unit_summary_local(u_kh)
        else:
            kh_sid = t.get("kharej_server_id") or ""
            if not kh_sid:
                kh_ok = False
                kh_txt = f"service name = {u_kh}\nkharej server missing"
            else:
                c, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
                kh_txt = unit_summary_remote(c, u_kh)
                c.close()
    except Exception as e:
        kh_ok = False
        kh_txt = f"service name = {u_kh}\nERROR: {str(e)}"

    return JSONResponse({
        "ok": True,
        "iran_ok": iran_ok,
        "kharej_ok": kh_ok,
        "iran": ir_txt,
        "kharej": kh_txt
    })

@app.get("/api/tunnels/logs/{tkey}")
def tunnels_logs(req: Request, tkey: str, side: str, lines: int = 200, _: bool = Depends(login_required)):
    t = next((x for x in load_tunnels() if x.get("key") == tkey), None)
    if not t:
        return JSONResponse({"ok": False, "msg": "not found"})

    mode, local_side, iran, kh = resolve_tunnel_servers(t)
    side = (side or "").strip().lower()
    tid = t["tid"]
    unit = remote_unit_name(side, tid)

    try:
        if side not in ("iran", "kharej"):
            return JSONResponse({"ok": False, "msg": "bad side"})

        if side == local_side:
            txt = unit_logs_local(unit, lines=lines)
            return JSONResponse({"ok": True, "text": txt})

        if side == "iran":
            iran_sid = t.get("iran_server_id") or ""
            if not iran_sid:
                return JSONResponse({"ok": False, "msg": "iran server missing"})
            c, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
            txt = unit_logs_remote(c, unit, lines=lines)
            c.close()
            return JSONResponse({"ok": True, "text": txt})

        kh_sid = t.get("kharej_server_id") or ""
        if not kh_sid:
            return JSONResponse({"ok": False, "msg": "kharej server missing"})
        c, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
        txt = unit_logs_remote(c, unit, lines=lines)
        c.close()
        return JSONResponse({"ok": True, "text": txt})

    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)})

@app.post("/api/tunnels/action/{tkey}")
def tunnels_action(req: Request, tkey: str, side: str = Form(...), action: str = Form(...), _: bool = Depends(login_required)):
    t = next((x for x in load_tunnels() if x.get("key") == tkey), None)
    if not t:
        return JSONResponse({"ok": False, "msg": "not found"})

    mode, local_side, iran, kh = resolve_tunnel_servers(t)
    side = (side or "").strip().lower()
    action = (action or "").strip().lower()
    unit = remote_unit_name(side, t["tid"])

    try:
        if action not in ("start", "stop", "restart", "enable", "disable"):
            return JSONResponse({"ok": False, "msg": "bad action"})
        if side not in ("iran", "kharej"):
            return JSONResponse({"ok": False, "msg": "bad side"})

        if side == local_side:
            _ = local_service_action(unit, action)
            return JSONResponse({"ok": True, "msg": unit_summary_local(unit)})

        if side == "iran":
            iran_sid = t.get("iran_server_id") or ""
            if not iran_sid:
                return JSONResponse({"ok": False, "msg": "iran server missing"})
            c, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
            _ = remote_service_action(c, unit, action)
            s = unit_summary_remote(c, unit)
            c.close()
            return JSONResponse({"ok": True, "msg": s})

        kh_sid = t.get("kharej_server_id") or ""
        if not kh_sid:
            return JSONResponse({"ok": False, "msg": "kharej server missing"})
        c, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
        _ = remote_service_action(c, unit, action)
        s = unit_summary_remote(c, unit)
        c.close()
        return JSONResponse({"ok": True, "msg": s})

    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)})

@app.post("/tunnels/uninstall/{tkey}")
def tunnels_uninstall(req: Request, tkey: str, _: bool = Depends(login_required)):
    tunnels = load_tunnels()
    t = next((x for x in tunnels if x.get("key") == tkey), None)
    if not t:
        return RedirectResponse("/tunnels", status_code=302)

    mode, local_side, iran, kh = resolve_tunnel_servers(t)
    tid = t["tid"]
    u_ir = remote_unit_name("iran", tid)
    u_kh = remote_unit_name("kharej", tid)

    errors = []

    iran_sid = t.get("iran_server_id") or ""
    kh_sid = t.get("kharej_server_id") or ""

    try:
        if local_side == "iran":
            local_uninstall_unit(u_ir)
        else:
            if iran_sid:
                c, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
                remote_uninstall_unit(c, u_ir)
                c.close()
            else:
                errors.append("iran server missing")
    except Exception as e:
        errors.append(f"iran uninstall error: {e}")

    try:
        if local_side == "kharej":
            local_uninstall_unit(u_kh)
        else:
            if kh_sid:
                c, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
                remote_uninstall_unit(c, u_kh)
                c.close()
            else:
                errors.append("kharej server missing")
    except Exception as e:
        errors.append(f"kharej uninstall error: {e}")

    tunnels = [x for x in tunnels if x.get("key") != tkey]
    save_tunnels(tunnels)

    if errors:
        msg = ("removed with warnings: " + " | ".join(str(x) for x in errors)).replace(" ", "+")
        return RedirectResponse("/tunnels?err=" + msg, status_code=302)

    return RedirectResponse("/tunnels?ok=removed", status_code=302)

@app.post("/tunnels/change/{tkey}")
def tunnels_change(
    req: Request,
    tkey: str,
    new_proto: str = Form(...),
    new_tun_port: str = Form(...),
    new_forward_ports: str = Form(""),
    new_ssh_id: str = Form(""),
    new_params: str = Form(""),
    _: bool = Depends(login_required)
):
    tunnels = load_tunnels()
    t = next((x for x in tunnels if x.get("key") == tkey), None)
    if not t:
        return RedirectResponse("/tunnels", status_code=302)

    method = t["method"]

    new_proto = normalize_proto(new_proto.strip())
    new_tun_port = (new_tun_port or "").strip()
    new_forward_ports = (new_forward_ports or "").strip()
    new_ssh_id = (new_ssh_id or "").strip()
    new_params = normalize_params(new_params)

    if method not in ("direct", "reverse"):
        return RedirectResponse(f"/tunnels/manage/{tkey}?err=bad+method", status_code=302)

    ok_pair, proto_norm, p1, p2 = parse_proto_pair_allowed(new_proto)
    if not ok_pair:
        return RedirectResponse(f"/tunnels/manage/{tkey}?err=bad+proto", status_code=302)
    new_proto = proto_norm

    if not valid_port(new_tun_port):
        return RedirectResponse(f"/tunnels/manage/{tkey}?err=bad+tun+port", status_code=302)

    if proto_needs_ssh_id(new_proto) and not valid_tid(new_ssh_id):
        return RedirectResponse(f"/tunnels/manage/{tkey}?err=SSH_ID+required", status_code=302)

    if not valid_params(new_params):
        return RedirectResponse(f"/tunnels/manage/{tkey}?err=bad+params", status_code=302)

    mode, local_side, iran, kh = resolve_tunnel_servers(t)

    iran_ip = t["iran_ip"]
    kh_ip = t["kharej_ip"]

    forwarder_side = "iran" if method == "direct" else "kharej"
    if need_forward_ports(method, forwarder_side):
        if not new_forward_ports:
            return RedirectResponse(f"/tunnels/manage/{tkey}?err=FORWARD_PORTS+required", status_code=302)
        if not valid_forward_spec(new_forward_ports):
            return RedirectResponse(f"/tunnels/manage/{tkey}?err=bad+FORWARD_PORTS", status_code=302)

    c_iran = None
    c_kh = None

    try:
        if local_side in ("iran", "kharej"):
            local_ensure()

        iran_sid = t.get("iran_server_id") or ""
        kh_sid = t.get("kharej_server_id") or ""

        if local_side != "iran":
            if not iran_sid:
                raise RuntimeError("iran server missing")
            c_iran, _ = ssh_connect_server_retry(iran_sid, timeout=10, retries=1)
            remote_ensure(c_iran)

        if local_side != "kharej":
            if not kh_sid:
                raise RuntimeError("kharej server missing")
            c_kh, _ = ssh_connect_server_retry(kh_sid, timeout=10, retries=1)
            remote_ensure(c_kh)

        sshid_arg = new_ssh_id if proto_needs_ssh_id(new_proto) else ""

        cli_kh_direct = build_cli("kharej", "direct", new_proto, t["tid"], iran_ip, new_tun_port, params=new_params)

        cli_ir_direct = build_cli(
            "iran", "direct", new_proto, t["tid"], kh_ip, new_tun_port,
            new_forward_ports if need_forward_ports("direct", "iran") else "",
            sshid_arg if need_forward_ports("direct", "iran") else "",
            params=new_params
        )

        cli_ir_reverse = build_cli("iran", "reverse", new_proto, t["tid"], kh_ip, new_tun_port, params=new_params)

        cli_kh_reverse = build_cli(
            "kharej", "reverse", new_proto, t["tid"], iran_ip, new_tun_port,
            new_forward_ports if need_forward_ports("reverse", "kharej") else "",
            sshid_arg if need_forward_ports("reverse", "kharej") else "",
            params=new_params
        )

        if method == "direct":
            if local_side == "kharej":
                local_run_cli(cli_kh_direct)
            else:
                remote_run_cli(c_kh, cli_kh_direct)

            if local_side == "iran":
                local_run_cli(cli_ir_direct)
            else:
                remote_run_cli(c_iran, cli_ir_direct)

        else:
            if local_side == "iran":
                local_run_cli(cli_ir_reverse)
            else:
                remote_run_cli(c_iran, cli_ir_reverse)

            if local_side == "kharej":
                local_run_cli(cli_kh_reverse)
            else:
                remote_run_cli(c_kh, cli_kh_reverse)

        try:
            if c_iran: c_iran.close()
        except Exception:
            pass
        try:
            if c_kh: c_kh.close()
        except Exception:
            pass

        t.update({
            "proto": new_proto,
            "tun_port": new_tun_port,
            "forward_ports": new_forward_ports,
            "ssh_id": new_ssh_id,
            "params": new_params
        })
        save_tunnels(tunnels)
        return RedirectResponse(f"/tunnels/manage/{tkey}?ok=saved", status_code=302)

    except Exception as e:
        try:
            if c_iran: c_iran.close()
        except Exception:
            pass
        try:
            if c_kh: c_kh.close()
        except Exception:
            pass
        return RedirectResponse(f"/tunnels/manage/{tkey}?err=" + str(e).replace(" ", "+"), status_code=302)


@app.exception_handler(HTTPException)
async def http_exception_handler(req: Request, exc: HTTPException):
    if exc.status_code == 401:
        if req.url.path.startswith("/api/"):
            return JSONResponse(
                {"ok": False, "code": "SESSION_EXPIRED", "msg": "Session expired"},
                status_code=401
            )
        return RedirectResponse("/login?expired=1", status_code=302)
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)


def reload_server_by_id(sid: str) -> Optional[Dict[str, Any]]:
    sid = (sid or "").strip()
    if not sid:
        return None
    for s in load_servers():
        if s.get("id") == sid:
            return s
    return None

def ssh_connect_retry(host: str, port: int, username: str, password: str, timeout=10, retries: int = 1) -> paramiko.SSHClient:
    last_err = None
    for attempt in range(retries + 1):
        try:
            c = paramiko.SSHClient()
            c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(
                hostname=host,
                port=int(port),
                username=username,
                password=password,
                timeout=timeout,
                banner_timeout=timeout,
                auth_timeout=timeout
            )
            return c
        except Exception as e:
            last_err = e
            time.sleep(0.2)
    raise RuntimeError(str(last_err) if last_err else "ssh connect failed")

def ssh_connect_server_retry(sid: str, timeout=10, retries: int = 1) -> Tuple[paramiko.SSHClient, Dict[str, Any]]:
    """
    Connect using server id. On failure, reload servers.json and retry once with reloaded info.
    """
    s = reload_server_by_id(sid)
    if not s:
        raise RuntimeError("server not found")

    try:
        c = ssh_connect_retry(s["host"], int(s["ssh_port"]), s["ssh_user"], s["ssh_pass"], timeout=timeout, retries=retries)
        return c, s
    except Exception:
        s2 = reload_server_by_id(sid)
        if not s2:
            raise RuntimeError("server not found (after reload)")
        c = ssh_connect_retry(s2["host"], int(s2["ssh_port"]), s2["ssh_user"], s2["ssh_pass"], timeout=timeout, retries=retries)
        return c, s2


def _reset_line_for_unit(unit: str) -> str:
    return f"sudo systemctl restart {unit} 2>/dev/null || true"

def _local_reset_status(unit: str) -> bool:
    line = _reset_line_for_unit(unit)
    cmd = f"""
set -e
test -f "{RESET_SCRIPT}" || exit 1
grep -Fqx '{line}' "{RESET_SCRIPT}" || exit 2
crontab -l 2>/dev/null | grep -Fq "{RESET_SCRIPT}" || exit 3
echo OK
"""
    p = subprocess.run(["bash","-lc", cmd], capture_output=True, text=True)
    return p.returncode == 0

def _remote_reset_status(c: paramiko.SSHClient, unit: str) -> bool:
    line = _reset_line_for_unit(unit)
    cmd = f"""
set -e
test -f "{RESET_SCRIPT}" || exit 1
grep -Fqx '{line}' "{RESET_SCRIPT}" || exit 2
crontab -l 2>/dev/null | grep -Fq "{RESET_SCRIPT}" || exit 3
echo OK
"""
    rc, out, err = ssh_exec_script(c, cmd, timeout=40)
    return rc == 0

def _local_reset_set(unit: str, mode: str, step: int) -> str:
    line = _reset_line_for_unit(unit)

    if mode == "hourly":
        cron_line = f"0 */{step} * * * {RESET_SCRIPT}"
    else:
        cron_line = f"*/{step} * * * * {RESET_SCRIPT}"

    script = f"""
set -e
RESET_SCRIPT="{RESET_SCRIPT}"
LINE='{line}'

if [ ! -f "$RESET_SCRIPT" ]; then
  cat > "$RESET_SCRIPT" <<EOF
#!/bin/bash
$LINE
sudo journalctl --vacuum-size=1M
EOF
  chmod +x "$RESET_SCRIPT" || true
else
  head -n1 "$RESET_SCRIPT" 2>/dev/null | grep -q '^#!/bin/bash' || (
    tmp="${{RESET_SCRIPT}}.tmp.$$"
    echo '#!/bin/bash' > "$tmp"
    cat "$RESET_SCRIPT" >> "$tmp"
    mv -f "$tmp" "$RESET_SCRIPT"
  )

  if ! grep -Fqx "$LINE" "$RESET_SCRIPT" 2>/dev/null; then
    if grep -q 'journalctl --vacuum-size=1M' "$RESET_SCRIPT" 2>/dev/null; then
      sed -i "/journalctl --vacuum-size=1M/i $LINE" "$RESET_SCRIPT" >/dev/null 2>&1 || true
    else
      echo "$LINE" >> "$RESET_SCRIPT"
      echo "sudo journalctl --vacuum-size=1M" >> "$RESET_SCRIPT"
    fi
  fi
  chmod +x "$RESET_SCRIPT" || true
fi

tmp="$(mktemp)"
crontab -l 2>/dev/null | grep -vF "$RESET_SCRIPT" > "$tmp" || true
echo "{cron_line}" >> "$tmp"
crontab "$tmp" >/dev/null 2>&1 || true
rm -f "$tmp" >/dev/null 2>&1 || true
echo "Cron set: {cron_line}"
"""
    p = subprocess.run(["bash","-lc", script], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout).strip() or "local cron set failed")
    return (p.stdout or "").strip() or "OK"

def _remote_reset_set(c: paramiko.SSHClient, unit: str, mode: str, step: int) -> str:
    line = _reset_line_for_unit(unit)

    if mode == "hourly":
        cron_line = f"0 */{step} * * * {RESET_SCRIPT}"
    else:
        cron_line = f"*/{step} * * * * {RESET_SCRIPT}"

    script = f"""
set -e
RESET_SCRIPT="{RESET_SCRIPT}"
LINE='{line}'

if [ ! -f "$RESET_SCRIPT" ]; then
  cat > "$RESET_SCRIPT" <<EOF
#!/bin/bash
$LINE
sudo journalctl --vacuum-size=1M
EOF
  chmod +x "$RESET_SCRIPT" || true
else
  head -n1 "$RESET_SCRIPT" 2>/dev/null | grep -q '^#!/bin/bash' || (
    tmp="${{RESET_SCRIPT}}.tmp.$$"
    echo '#!/bin/bash' > "$tmp"
    cat "$RESET_SCRIPT" >> "$tmp"
    mv -f "$tmp" "$RESET_SCRIPT"
  )

  if ! grep -Fqx "$LINE" "$RESET_SCRIPT" 2>/dev/null; then
    if grep -q 'journalctl --vacuum-size=1M' "$RESET_SCRIPT" 2>/dev/null; then
      sed -i "/journalctl --vacuum-size=1M/i $LINE" "$RESET_SCRIPT" >/dev/null 2>&1 || true
    else
      echo "$LINE" >> "$RESET_SCRIPT"
      echo "sudo journalctl --vacuum-size=1M" >> "$RESET_SCRIPT"
    fi
  fi
  chmod +x "$RESET_SCRIPT" || true
fi

tmp="$(mktemp)"
crontab -l 2>/dev/null | grep -vF "$RESET_SCRIPT" > "$tmp" || true
echo "{cron_line}" >> "$tmp"
crontab "$tmp" >/dev/null 2>&1 || true
rm -f "$tmp" >/dev/null 2>&1 || true
echo "Cron set: {cron_line}"
"""
    rc, out, err = ssh_exec_script(c, script, timeout=80)
    if rc != 0:
        raise RuntimeError((err or out).strip() or "remote cron set failed")
    return (out or "").strip() or "OK"

def _local_reset_remove(unit: str) -> str:
    line = _reset_line_for_unit(unit)
    script = f"""
set +e
RESET_SCRIPT="{RESET_SCRIPT}"
LINE='{line}'

tmp="$(mktemp)"
crontab -l 2>/dev/null | grep -vF "$RESET_SCRIPT" > "$tmp" || true
crontab "$tmp" >/dev/null 2>&1 || true
rm -f "$tmp" >/dev/null 2>&1 || true

if [ -f "$RESET_SCRIPT" ]; then
  tmp2="${{RESET_SCRIPT}}.tmp.$$"
  grep -vF "$LINE" "$RESET_SCRIPT" > "$tmp2" 2>/dev/null || true
  mv -f "$tmp2" "$RESET_SCRIPT" 2>/dev/null || true

  grep -q "systemctl restart" "$RESET_SCRIPT" 2>/dev/null || rm -f "$RESET_SCRIPT" >/dev/null 2>&1 || true
fi

echo OK
"""
    p = subprocess.run(["bash","-lc", script], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout).strip() or "local remove failed")
    return (p.stdout or "").strip() or "OK"

def _remote_reset_remove(c: paramiko.SSHClient, unit: str) -> str:
    line = _reset_line_for_unit(unit)
    script = f"""
set +e
RESET_SCRIPT="{RESET_SCRIPT}"
LINE='{line}'

tmp="$(mktemp)"
crontab -l 2>/dev/null | grep -vF "$RESET_SCRIPT" > "$tmp" || true
crontab "$tmp" >/dev/null 2>&1 || true
rm -f "$tmp" >/dev/null 2>&1 || true

if [ -f "$RESET_SCRIPT" ]; then
  tmp2="${{RESET_SCRIPT}}.tmp.$$"
  grep -vF "$LINE" "$RESET_SCRIPT" > "$tmp2" 2>/dev/null || true
  mv -f "$tmp2" "$RESET_SCRIPT" 2>/dev/null || true
  grep -q "systemctl restart" "$RESET_SCRIPT" 2>/dev/null || rm -f "$RESET_SCRIPT" >/dev/null 2>&1 || true
fi

echo OK
"""
    rc, out, err = ssh_exec_script(c, script, timeout=80)
    if rc != 0:
        raise RuntimeError((err or out).strip() or "remote remove failed")
    return (out or "").strip() or "OK"


@app.get("/api/tunnels/cron/{tkey}/status")
def tunnels_cron_status(req: Request, tkey: str, _: bool = Depends(login_required)):
    t = next((x for x in load_tunnels() if x.get("key") == tkey), None)
    if not t:
        return JSONResponse({"ok": False, "msg": "not found"})

    mode, local_side, iran, kh = resolve_tunnel_servers(t)
    tid = t["tid"]
    u_ir = remote_unit_name("iran", tid)
    u_kh = remote_unit_name("kharej", tid)

    ir_has = False
    kh_has = False
    ir_msg = ""
    kh_msg = ""

    try:
        if local_side == "iran":
            ir_has = _local_reset_status(u_ir)
        else:
            if not iran:
                ir_msg = "iran server missing"
            else:
                c = ssh_connect(iran["host"], int(iran["ssh_port"]), iran["ssh_user"], iran["ssh_pass"])
                ir_has = _remote_reset_status(c, u_ir)
                c.close()
    except Exception as e:
        ir_msg = str(e)

    try:
        if local_side == "kharej":
            kh_has = _local_reset_status(u_kh)
        else:
            if not kh:
                kh_msg = "kharej server missing"
            else:
                c = ssh_connect(kh["host"], int(kh["ssh_port"]), kh["ssh_user"], kh["ssh_pass"])
                kh_has = _remote_reset_status(c, u_kh)
                c.close()
    except Exception as e:
        kh_msg = str(e)

    want_remove = bool(ir_has and kh_has)

    return JSONResponse({
        "ok": True,
        "iran_has": ir_has,
        "kharej_has": kh_has,
        "want_remove": want_remove,
        "iran_msg": ir_msg,
        "kharej_msg": kh_msg
    })


def _validate_cron_params(mode: str, step: str) -> Tuple[str, int]:
    mode = (mode or "").strip().lower()
    step = (step or "").strip()

    if mode not in ("minute", "hourly"):
        raise RuntimeError("bad mode")

    if not re.match(r"^\d+$", step or ""):
        raise RuntimeError("bad step")

    n = int(step)
    if mode == "hourly":
        if not (1 <= n <= 12):
            raise RuntimeError("hourly step must be 1-12")
    else:
        if not (5 <= n <= 55):
            raise RuntimeError("minute step must be 5-55")
    return mode, n


@app.post("/api/tunnels/cron/{tkey}/set")
def tunnels_cron_set(
    req: Request,
    tkey: str,
    mode: str = Form(...),
    step: str = Form(...),
    _: bool = Depends(login_required)
):
    t = next((x for x in load_tunnels() if x.get("key") == tkey), None)
    if not t:
        return JSONResponse({"ok": False, "msg": "not found"})

    try:
        mode, n = _validate_cron_params(mode, step)
    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)})

    mode_t, local_side, iran, kh = resolve_tunnel_servers(t)
    tid = t["tid"]
    u_ir = remote_unit_name("iran", tid)
    u_kh = remote_unit_name("kharej", tid)

    ir_res = ""
    kh_res = ""

    c_iran = None
    c_kh = None
    try:
        if local_side in ("iran","kharej"):
            local_ensure()

        if local_side != "iran":
            if not iran:
                raise RuntimeError("iran server missing")
            c_iran = ssh_connect(iran["host"], int(iran["ssh_port"]), iran["ssh_user"], iran["ssh_pass"])
        if local_side != "kharej":
            if not kh:
                raise RuntimeError("kharej server missing")
            c_kh = ssh_connect(kh["host"], int(kh["ssh_port"]), kh["ssh_user"], kh["ssh_pass"])

        if local_side == "iran":
            ir_res = _local_reset_set(u_ir, mode, n)
        else:
            ir_res = _remote_reset_set(c_iran, u_ir, mode, n)

        if local_side == "kharej":
            kh_res = _local_reset_set(u_kh, mode, n)
        else:
            kh_res = _remote_reset_set(c_kh, u_kh, mode, n)

        return JSONResponse({"ok": True, "msg": "cronjob set", "iran": ir_res, "kharej": kh_res})

    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)})

    finally:
        try:
            if c_iran: c_iran.close()
        except Exception:
            pass
        try:
            if c_kh: c_kh.close()
        except Exception:
            pass


@app.post("/api/tunnels/cron/{tkey}/remove")
def tunnels_cron_remove(req: Request, tkey: str, _: bool = Depends(login_required)):
    t = next((x for x in load_tunnels() if x.get("key") == tkey), None)
    if not t:
        return JSONResponse({"ok": False, "msg": "not found"})

    mode_t, local_side, iran, kh = resolve_tunnel_servers(t)
    tid = t["tid"]
    u_ir = remote_unit_name("iran", tid)
    u_kh = remote_unit_name("kharej", tid)

    ir_res = ""
    kh_res = ""

    c_iran = None
    c_kh = None
    try:
        if local_side in ("iran","kharej"):
            local_ensure()

        if local_side != "iran" and iran:
            c_iran = ssh_connect(iran["host"], int(iran["ssh_port"]), iran["ssh_user"], iran["ssh_pass"])
        if local_side != "kharej" and kh:
            c_kh = ssh_connect(kh["host"], int(kh["ssh_port"]), kh["ssh_user"], kh["ssh_pass"])

        if local_side == "iran":
            ir_res = _local_reset_remove(u_ir)
        else:
            if not c_iran:
                raise RuntimeError("iran server missing")
            ir_res = _remote_reset_remove(c_iran, u_ir)

        if local_side == "kharej":
            kh_res = _local_reset_remove(u_kh)
        else:
            if not c_kh:
                raise RuntimeError("kharej server missing")
            kh_res = _remote_reset_remove(c_kh, u_kh)

        return JSONResponse({"ok": True, "msg": "cronjob removed", "iran": ir_res, "kharej": kh_res})

    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)})

    finally:
        try:
            if c_iran: c_iran.close()
        except Exception:
            pass
        try:
            if c_kh: c_kh.close()
        except Exception:
            pass
